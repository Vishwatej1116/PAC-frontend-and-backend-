package com.cts.hms.pac.entity;

import java.util.Date;

public class Slots {

	private Long id;
	private Date slotDate;
	private String slotTime;
	private Long centerId;
	private Long userId;
	
	public Slots() {}

	public Slots(Long id, Date slotdate, String slotTime, Long centerId, Long userId) {
		super();
		this.id = id;
		this.slotDate = slotdate;
		this.slotTime = slotTime;
		this.centerId = centerId;
		this.userId = userId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getSlotDate() {
		return slotDate;
	}

	public void setSlotDate(Date slotDate) {
		this.slotDate = slotDate;
	}

	public String getSlotTime() {
		return slotTime;
	}

	public void setSlotTime(String slotTime) {
		this.slotTime = slotTime;
	}

	public Long getCenterId() {
		return centerId;
	}

	public void setCenterId(Long centerId) {
		this.centerId = centerId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "Slots [id=" + id + ", slotDate=" + slotDate + ", slotTime=" + slotTime + ", centerId="
				+ centerId + ", userId=" + userId + "]";
	}
}
