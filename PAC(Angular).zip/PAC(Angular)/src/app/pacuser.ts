export class Pacuser{
        firstName : string='';
        lastName : string='';
        userName: string='';
        email: string='';
        age: number=0;
        password: string='';
}