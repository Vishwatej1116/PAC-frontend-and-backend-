import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PacUserService } from '../pac-user.service';
import { Pacuser } from '../pacuser';

@Component({
  selector: 'app-signup-page',
  templateUrl: './signup-page.component.html',
  styleUrls: ['./signup-page.component.css']
})
export class SignupPageComponent implements OnInit {
  invalidLogin:boolean = false;
  nextPage:boolean = false
  firstName:any =""
  lastName:any =""
  userName:any =""
  email:any = ""
  gender:any = ""
  age:number = 0
  password:any = ""
  confirmPassword:any = ""
  
  // pacuser : any;//Pacuser  = new Pacuser("","","","","",0,"");
  pacuser:Pacuser=new Pacuser();
  message : any;
  constructor(private router: Router, private service: PacUserService) { }

  ngOnInit() {
  }
  nextpage(){
    console.log("sample text")
    if(this.firstName != "" && this.lastName != "" && this.age >= 15 && this.email != ""){
      this.nextPage = !this.nextPage
      this.invalidLogin = false
    }
    else{
      this.invalidLogin = true
    }

  }
  backPage(){
    this.nextPage = !this.nextPage
  }
  public signUp(){
    if(this.userName != "" && this.password !="" && this.password == this.confirmPassword){
      
      this.invalidLogin = false
    }
    else{
      this.invalidLogin = true
    }
    
      let reponse = this.service.doSignupdata(this.pacuser);
      reponse.subscribe(data => {
        this.message = data;
      });
    }
  }

