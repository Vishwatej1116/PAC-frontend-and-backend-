import { Component, OnInit } from '@angular/core';
import { PacUserService } from '../pac-user.service';
import { TestObject } from 'protractor/built/driverProviders';

@Component({
  selector: 'app-admin-homepage',
  templateUrl: './admin-homepage.component.html',
  styleUrls: ['./admin-homepage.component.css']
})
export class AdminHomepageComponent implements OnInit {
  userTable:boolean = false;
  vCenters:boolean = false
  sampleData: any
  vCentersData: any
  constructor(public service: PacUserService) { }

  ngOnInit() {
    let response1 = this.service.getSampleData();
    response1.subscribe(data => this.sampleData = data);

    let response2 = this.service.getVCentersData();
    response2.subscribe(vdata => this.vCentersData = vdata);
  }
  
  onBtnClick(value:string){
    if(value == "user"){
      this.userTable = true
      this.vCenters = false
    }
    else if(value == "vCenters"){
      this.vCenters = true
      this.userTable = false
    }
  }
}
