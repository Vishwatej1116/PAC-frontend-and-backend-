import { Component, OnInit } from '@angular/core';
import { PacUserService } from '../pac-user.service';

@Component({
  selector: 'app-user-homepage',
  templateUrl: './user-homepage.component.html',
  styleUrls: ['./user-homepage.component.css']
})
export class UserHomepageComponent implements OnInit {
  userTable:boolean = false;
  vCenters:boolean = false
  helpInfo:boolean = false
  constructor(public service: PacUserService) { }

  ngOnInit(): void {
  }
  onBtnClick(value:string){
    if(value == "user"){
      this.userTable = true
      this.vCenters = false
      this.helpInfo = false
    }
    else if(value == "vCenters"){
      this.userTable = false
      this.vCenters = true
      this.helpInfo = false
    }
    else if(value == "helpInfo"){
      this.userTable = false
      this.vCenters = false
      this.helpInfo = true
    }
  }
}
