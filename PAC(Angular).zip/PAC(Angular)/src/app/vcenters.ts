export class Vcenters{
    constructor(
        id: number,
        name : string,
        pinCode: number
       
    ){}
}