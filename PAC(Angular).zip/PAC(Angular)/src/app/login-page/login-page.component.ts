import { Component, OnInit } from '@angular/core';
import { UrlSegment } from '@angular/router';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AppComponent } from '../app.component';
import { PacUserService } from '../pac-user.service';
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  invalidLogin:boolean = false;
  userName:any =""
  password:any = ""

  constructor(private router: Router,public appComp: AppComponent, public service: PacUserService) { }

  ngOnInit(): void {
  }

  validate(typeOfLogin:any){

    if(this.userName == this.password){
      this.invalidLogin = false

      //this.appComp.userName = this.userName
      this.service.setUserName(this.userName)
      //this.appComp.loggedIn = true
      this.service.setLoggedIn(true)
      if(typeOfLogin == 'admin'){
        this.router.navigate(['../adminPage']);
      }
      else{
        this.router.navigate(['../userPage']);
      }
    }
    else{
      this.invalidLogin = true
    }
  }
  openSignUp(){
    this.router.navigate(['../signup'])
  }

}
